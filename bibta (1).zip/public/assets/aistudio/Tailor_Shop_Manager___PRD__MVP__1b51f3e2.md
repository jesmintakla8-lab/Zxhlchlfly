# Tailor Shop Manager — PRD (MVP)

Version 1.0 (confirmed by the owner) · Audience: AI builder and human developer · Owner: shop owner

## 1. Summary

A web app for a single tailor shop in Bangladesh whose customers are almost all Bangladesh Air Force personnel. It replaces the paper notebook: take orders, record measurements, print invoices and cutting slips, track delivery status, and track who still owes money.

Customers are of two completely separate kinds, **Officers** and **Airmen**. They have separate orders, order numbers, customer lists and order forms. They never mix.

The **BD number** (the Air Force ID number) is the key identifier of every customer.

**Reference app.** A similar app was shown in a screen recording. It is inspiration for how features work only. Do not copy its menu, theme, layout, typography or any feature not described here.

## 2. Goals and non-goals

### Goals

- Take an Officer order quickly, with items, prices, measurements, discount and advance.
- Take an Airman order for the yearly bulk batch, with IV-Numbers and no prices.
- Print a customer invoice and a tailor cutting slip.
- Track status (Pending, Cutting Slip – Done, Delivered) and money owed.
- Show an automatic Dashboard of orders, sales, collection and due.
- Keep the same data on every device.

### Non-goals for the MVP (do not build)

- Login, accounts, roles (viewer/guest) — later, with real security, before the app is released to about 50–60 devices.
- Branch field, Export buttons, staff or worker management, staff summary, salary or "khoroch" pages.
- SMS or WhatsApp notifications, any payment gateway or online payment (never).
- Partial payments.
- Any feature not described in this document. If something is unclear, ask; do not invent.

## 3. Users and platform

- **One kind of user** with full access (add, edit, delete): the owner (in the MVP only the owner uses it, for testing; about 50–60 staff devices after release). There is **no login** in the MVP.
- One shop. No branches.
- Responsive web app used on phones and computers, installable as a PWA. All devices see the same shared data.
- Languages: English and Bangla, with a switch. Dark mode toggle. Currency is taka (৳).
- Look and feel: clean, modern, white cards, soft colours. Blue for main buttons, red for money owed, green for done or received. Status badges: orange Pending, purple Cutting Slip – Done, green Delivered. Loading placeholders and friendly empty-state messages everywhere.

## 4. Key concepts and data model

**Customer** — category (Officer or Airman), BD number, name, phone (optional). A BD number is unique within its category. Customers are created automatically when an order is saved for a new BD number, or manually with **Add Customer**. Rank (F/L, S/L, W/C …) is part of the name text; there is no rank field.

**Order** — category, order number, customer (BD number and name), status, order date, items, measurements, notes, money fields (Officer only), dates. Statuses: Pending → Cutting Slip – Done → Delivered. Any direction is allowed.

**Order item** — item name, quantity, and for Officer orders a **price copied at the time of the order**. Later price changes in Settings never change existing orders. Airman items also carry an **IV-Number** and no price.

**Measurements** — one set per order.

- Shirt: Length, Chest, Belly, Hip, Shoulder, Sleeve, Collar, Front, Back, Hand Written Notes, Extra Notes.
- Pant: Length, Waist, Hip, High, Thai, Leg Open, Hand Written Notes, Extra Notes.
- Use these exact field names, even if they look unusual. Fill whichever applies. No smart logic.
- Both notes fields print on the cutting slip.

**Payment record** (Officer orders) — amount, date. Created when Pay is pressed.

**Draft** — an incomplete order saved on the server, shown only in Drafts. Has no order number.

**Settings data** — items and prices, default discount type, upcoming-delivery days, invoice template, and editable lists for Ribbon, Trade, Office and Running Years.

## 5. Order numbers

- Officer orders and Airman orders each have their own sequence: 1, 2, 3 …
- A number is assigned only when an order is **saved as a real order**, never for a draft.
- When an order is deleted, **all later orders in the same category move down by one** so the sequence stays continuous (delete #522 and #523 becomes #522).
- Consequence accepted by the owner: printed invoices and slips may show an old number. Orders are found by order number, BD number or name, via search.

## 6. Money rules (Officer orders)

- **Total Amount** = sum of price × quantity of all items (automatic).
- **Discount** is optional, as a percentage or a flat taka amount. The default type is set in Settings and can be overridden per order (type "10%" or a taka value).
- **Advance** is the amount paid up front, 0 by default.
- **Due** = Total − Discount − Advance − any Pay amounts. It is calculated and cannot be typed.
- **Pay** (button "Pay ৳300") appears on a **Delivered** order whose Due is above 0. It means "I received the rest in cash", not an online payment. It clears the whole remaining Due and stores a payment record with the date. No partial payments.
- **Editing after payment.** If items are added to an order that was already paid, the money already received stays. Due becomes the new amount minus what was received (500 paid, total now 1000 → Due 500) and Pay appears again. The old payment record stays visible.
- Due is shown in red when above 0.

## 7. Features and screens

### 7.1 Orders (Officer) — the main screen

- **Search** by name, phone, BD number or order number.
- Two cards: **Upcoming to Deliver** (count of not-yet-delivered orders with a delivery date within the number of days set in Settings) and **Due After Delivery** (total taka and number of Delivered orders with Due above 0). Tapping a card filters the list.
- Tabs: All, Pending, Delivered, Cutting Slip – Done. Sort dropdown (newest first by default).
- Order card: order number, "Officer" badge, customer name, status dropdown, BD number, order date, delivery date, Total / Advance / Due, Pay button when applicable, and icons for print, view invoice, edit, delete. Tapping the card opens the details.
- Drafts are **not** shown here.

### 7.2 New / Edit Officer Order

Fields in this order:

1. **Items:** searchable dropdown of items with prices, quantity, **Add Item**. Many items per order. Price and total update automatically.
2. **Shirt** and **Pant** measurement boxes.
3. **BD Number**, **Customer Name**, **Phone** (blank-friendly, never labelled "optional"), **Order Date** (today by default), **Delivery Date**, **Ribbon** (dropdown).
4. **Total Amount**, **Discount**, **Advance**, **Due**.
5. Buttons: **Cancel**, **Save Order**, **Print Invoice**, **Cutting Slip**, plus a way to **Save as Draft**.

Behaviour:

- Typing a name suggests saved customers; tapping one fills name and BD number. Typing an existing BD number fills the saved name. The BD number identifies the person.
- **Required to save:** customer name, BD number, at least one item. Otherwise show a clear error.
- **Delivery Date is optional** and can be set or changed later by editing.
- Any order can be edited at any time, including Delivered ones.
- The form autosaves on the device while typing and shows "Draft saved locally".
- When editing an existing order with unsaved changes, show "Unsaved changes" and rename the main button to **Update Order**.

### 7.3 Drafts

- A draft needs at least a **BD number and one item**.
- Saved on the server, so it appears on every device. Listed in a separate Drafts area, not in Orders.
- Opening a draft and saving it completes it: it gets an order number and moves into Orders. Drafts can be deleted.
- Officer and Airman drafts are both supported.

### 7.4 Order details

- Header: order number, customer, status dropdown.
- Customer info: name, phone, BD number.
- Order info: order date, delivery date, date delivered, ribbon.
- Payment info: total, advance, due, and payment records.
- Items list.
- Bottom buttons: **Print Slip**, **Invoice**, **Edit Order**.

### 7.5 Status

- Changed manually by a dropdown on the card and on the details page. Movement in any direction is allowed.
- The delivered date is saved when set to Delivered and cleared if the order moves back.

**Delivery screen.** A separate **Delivery** button sits beside New Order and New Airman Order. It opens a screen where you search orders by name, phone, BD number or order number, with Officer and Airman tabs, and each result has a **Deliver** button that sets the order to Delivered with today’s date.

- It lists orders that are not yet Delivered.
- It is optional: you can also change the status dropdown straight from Cutting Slip – Done (or Pending) to Delivered, without using this screen.

### 7.6 Airman Orders (separate page and form)

Added through a **separate button** from Officer orders.

- **Page:** summary cards for Battle Uniform, Half Sleeve, Full Sleeve, Summer Ceremonial, Winter Ceremonial and MODC Uniform, showing the **total quantity** ordered per type, plus the same search, tabs, sort and card list, plus a **Running Year** filter (e.g. 2026–2027). Item "Half Sleeve Shirt" counts under Half Sleeve and "Full Sleeve Shirt" under Full Sleeve.
- **Form:** items with quantity and an **IV-Number** beside each item picker (required to save; an IV-Number belongs to one person, so another BD number cannot use it, but the same person can repeat it across their items); the same Shirt and Pant measurement boxes; **BD Number** (required), **Name** (optional), **Phone** (optional), **Trade**, **Ribbon**, **Office**, **Running Year** with **Add Year**.
- No prices, discount, advance, due or delivery date. No Pay button.
- If name is empty, display "Airman" plus the BD number.
- Required to save: BD number, at least one item, and an IV-Number on each item.
- Same statuses, details page, edit, delete, drafts and printing as Officer orders. Airman has its own order counter.
- Trade, Ribbon and Office are simple editable lists. Ribbon starts with 0, 3, 4 and 6. Trade and Office start empty and are low priority.

### 7.7 Customers and Customer History

- Page with **Officer** and **Airman** tabs, search (name, phone, BD number) and sort.
- Customer card: name, phone, BD number, **Orders** count, **Spent**, **Due** (red above 0), with buttons for history, edit, delete. No export.
- Button **Add Customer**: BD Number, Name, Phone (blank-friendly), Officer or Airman.
- **Customer History:** searchable list of everyone with Orders / Spent / Due. Tapping a person shows all their orders with status, total and due.

### 7.8 Dashboard (automatic)

- Four groups: **Today, This Week, This Month, All Time**. Each shows Orders, Sales, Collection, Due.
- Quick numbers: total customers, upcoming deliveries, delivered orders.
- Charts: orders and revenue by month (bar), order status (donut: Pending / Delivered / Due), weekly or daily chart, and a Recent Orders table.
- **Sales** = order totals after discount, counted on the order date. **Collection** = advances (counted on the order date) plus Pay amounts (counted on the Pay date). **Due** = money still unpaid.
- Tapping a number or card shows the details behind it.
- Dashboard covers Officer orders (money). Airman orders have no money.

### 7.9 Settings

- **Items & Prices:** add, edit, remove (§9).
- **Default discount type:** percentage or taka.
- **Upcoming delivery days:** e.g. 3.
- **Invoice template:** shop name, logo, terms.
- **Editable lists:** Ribbon values (starting with 0, 3, 4, 6), Trade, Office, Running Years.
- **Install app:** link and QR code to add to the home screen.
- Removed because there is no login: profile email, display name, logout.

* **Print paper size:** default A4, selectable for the invoice and cutting slip.

## 8. Printing

1. **Invoice** (customer copy): from the Settings template — shop name, logo, items, totals, terms. Officer orders only.
2. **Cutting Slip** (for the tailor, with the cloth): order, items, all measurements, both notes fields. For Airman orders it also shows IV-Numbers. If an order has no items, show: "No cutting slip found for this category in the selected order."

Print paper size defaults to **A4** and can be changed in Settings.

## 9. Starter data (items and prices, ৳)

Keep the spelling exactly as written. Items marked "check" are unconfirmed; show them as editable in Settings.

Battle Uniform 800 · Half Sleeve Shirt 250 · Full Sleeve Shirt 250 · Uniform Pant 200 · Summer Ceremonial 1500 · Winter Ceremonial 1000 · Half Bush 1000 · Civil Shirt 500 · Civil Pant 600 (check) · Punjabi 500 · Paijama 400 · Jubba 800 (check) · Safari 2000 · Blazer 4000 · Suit 5000 · Meskit 2200 · Meskit Shirt 400 · APPULATE (MESKIT 700 (check) · keti 2000 · maintainnce coverall 1000 · MESKIT PANT 200 (check) · DUST COAT 400 · MISSON GANJI 1000 · FOTUA 400 · HALF BUSH UPOR PART 800 (check) · summer ceremonial upor part 1300 (check) · sleeping dress 600 (check) · MODC Uniform (no price; used only for Airman orders).

Note: "APPULATE (MESKIT" has an unmatched bracket; keep it as written until the owner says otherwise.

## 10. Main user flows

1. **New Officer order:** New Order → add items → measurements → BD number/name (autofill if known) → dates, money → Save (order number assigned) → optionally print.
2. **Save as draft:** same form → Save as Draft (needs BD number + one item) → appears in Drafts only → later open, finish, Save → becomes an order.
3. **Deliver and collect:** change status to Delivered → if Due above 0, Pay button appears → press Pay → Due 0, payment record stored.
4. **Mistake correction:** move status back to Pending, or edit the order. Dues and dashboard recalculate.
5. **Add items after delivery:** edit delivered order → add item → total rises → Due = difference → Pay appears again.
6. **Airman batch entry:** New Airman Order → items with IV-Numbers and quantities → measurements → BD number, trade, office, ribbon, running year → Save.
7. **Find an order:** search by order number, BD number, name or phone; or tap Upcoming / Due After Delivery.
8. **Delete an order:** delete icon → two-step confirmation → permanently removed; later order numbers in that category move down by one; customer and their other orders stay.
9. **Customer history:** Customers or Customer History → pick a person → see their orders, spent and due.

## 11. Assumptions made (confirm or change)

- Existing BD number wins over a different typed name; the saved name is used, and names are edited from the Customers page.
- Same item catalogue for Officer and Airman orders; prices hidden for Airman.
- The Total can be overridden by hand when editing an order; Due recalculates.
- Two-step confirmation applies to deleting any order, not only delivered ones.
- Deleting a customer is blocked while they have orders.
- If two devices edit one order, the last save wins.
- Dashboard numbers shrink when an order is deleted, since nothing is kept.
- Upcoming = not delivered and delivery date within the Settings number of days from today.

## 12. Open decisions and risks

**Decisions needed**

1. **"Delivery" button** — decided: a separate Delivery screen to search an order and mark it Delivered (see 7.5). It lists both Officer and Airman orders on separate tabs.
2. **IV-Number rules:** decided: required to save an Airman order, and unique to one person (the same person may repeat it across items). The builder does not need to know what it means.
3. **Ribbon, Trade and Office values:** Ribbon values are 0, 3, 4 and 6, editable in Settings. Trade and Office are low priority and start as empty editable lists.
4. **Invoice and slip paper size** is decided: default A4, changeable in Settings.
5. **Bangla digits:** should numbers appear in Bangla numerals when the language is Bangla?
6. **Unconfirmed prices** (the "check" items) and the "APPULATE (MESKIT" name.
7. **Airman cards:** confirm they show total quantity per type for the selected Running Year.

**Risks accepted for the MVP**

- **No login and permanent delete:** anyone with the link can view, change or delete everything, with no undo. Accepted because only the owner uses the MVP for testing. Before about 50–60 staff devices use it, add real login, security and a data backup.
- **Order renumbering:** printed documents can carry outdated order numbers, and two devices deleting at once could confuse numbering. Search by BD number and name is the fallback.
- **Concurrent edits:** last save wins, so one device can overwrite another's change.
- **Offline:** the app needs internet to share data; only the typing autosave is local.

## 13. Acceptance checklist

- An Officer order cannot be saved without name, BD number and one item; the error is clear.
- A draft needs BD number and one item, stays out of Orders, has no order number, and appears on a second device.
- Officer and Airman orders never share numbers, lists, customers or counters.
- Deleting order #N moves every later order in that category down by one.
- Pay clears the entire Due, stores the date, and Collection on the Dashboard rises by that amount on that date.
- Adding an item to a paid order keeps the paid amount and shows the new Due with a Pay button.
- Changing an item price in Settings does not change old orders.
- No Branch field, Export button, staff pages, notifications or payment gateway anywhere.
- The word "optional" appears nowhere in the UI.
- An IV-Number cannot be used by two different BD numbers; the same person can repeat it on several items.
- An Airman order cannot be saved without an IV-Number on each item.
