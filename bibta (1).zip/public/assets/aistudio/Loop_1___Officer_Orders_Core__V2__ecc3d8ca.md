# Loop 1 — Officer Orders Core (V2)

Part of the Tailor Shop Manager PRD v1.0 · Build only this loop, nothing else · Also read the App Map, and continue from the current app (section 0)

## 0. Continue from what exists (read first)

Nothing exists yet. **This loop creates the base of the app, and every later loop builds on it.** So create these as the permanent base, not as throwaway screens:

- **NEW — App shell and navigation.** One navigation bar. It starts with two links, Orders and Settings, and later loops add links to it. Build it so links can be added. Settings always stays last.
- **NEW — Orders screen.** This is the home screen. Later loops add buttons beside New Order, summary cards above the list, and tabs. Keep the top of the screen simple so these can be added without redesigning it.
- **NEW — Order card, New / Edit Order form, Order Details, Settings.** Later loops add buttons, sections and settings to these. They are never designed again.
- **NEW — Shared blocks:** search with sort, status badge, confirm dialogs, empty and loading states. Later screens reuse them.

See the App Map, section 6, for how each of these grows. Do not build any of that growth now.

## 1. Purpose and rules for the builder

Loop 1 is the smallest working order system: add an Officer order, see it in a list, open it, edit it, delete it. When this works end to end, the loop is done.

**Rules**

- Build only what is written here. If something is not in this document, leave it out and tell me what you left out. If something is unclear, ask.
- No login. One shared database so every device sees the same data.
- Officer orders only. Do not build Airman anything yet.
- Use the exact field names and spellings given here.
- Never write the word "optional" anywhere in the screen text.
- Dates use the format 2026-09-15. Money uses the ৳ sign. English only for now.

## 2. Screens in this loop

Four screens only: **Orders**, **New / Edit Order**, **Order Details**, **Settings**. A simple navigation with two links: Orders and Settings. The navigation will gain more links in later loops, so build it so links can be added.

## 3. Settings (only these three things)

1. **Items & Prices.** A list of items with their prices. Add an item, edit its name or price, remove an item. Load the starter list in section 9.
   - Items marked "check" show a small "check price" tag until the owner edits the price.
   - Removing or changing an item never changes orders that already exist.
2. **Default discount type.** Percentage or Taka. Used as the starting choice on every new order.
3. **Ribbon values.** An editable list of numbers. Starts with 0, 3, 4, 6.

## 4. Orders screen

- A **New Order** button at the top.
- A **search box**: finds by customer name, phone, BD number or order number.
- A **sort dropdown**: Newest first (default) and Oldest first.
- A list of **order cards**. Each card shows:
  - order number and a small "Officer" badge
  - customer name
  - a status badge that always reads "Pending" in this loop (no changing it yet)
  - BD number, order date, delivery date
  - Total, Advance and Due; Due is red when above 0
  - two icons: **edit** and **delete**
- Tapping a card opens Order Details.
- Empty state: a friendly message such as "No orders yet. Tap New Order to add the first one."
- Loading state: grey placeholder cards.

## 5. New / Edit Order form

The same form is used to create and to edit. Fields, in this order:

### 5.1 Items

- A searchable dropdown of all items, each showing its price.
- A quantity box (default 1) and an **Add Item** button.
- Many items can be added. Each added item shows name, quantity, price, line total, and a remove button.
- The price is copied into the order when the item is added.

### 5.2 Measurements

Two boxes. Fill whichever applies. No smart logic.

- **Shirt:** Length, Chest, Belly, Hip, Shoulder, Sleeve, Collar, Front, Back, Hand Written Notes, Extra Notes.
- **Pant:** Length, Waist, Hip, High, Thai, Leg Open, Hand Written Notes, Extra Notes.

### 5.3 Customer and dates

- **BD Number**, **Customer Name** (the rank like F/L is typed as part of the name), **Phone** (can be left blank).
- **Order Date** (today by default), **Delivery Date** (can be left blank).
- **Ribbon** dropdown from the Ribbon values list.
- If the BD number already belongs to a saved Officer customer, the name fills in automatically.

### 5.4 Money

- **Total Amount:** automatic, the sum of price × quantity.
- **Discount:** can be left blank. Type a plain number for taka, or a number with % for percent (for example 10%). Without a % sign, use the default type from Settings.
- **Advance:** 0 by default.
- **Due:** automatic, Total − Discount − Advance. It cannot be typed.
- When editing a saved order, the Total can be typed over by hand. Due recalculates.

### 5.5 Buttons

- **Cancel:** goes back to Orders. If there are unsaved changes, ask before leaving.
- **Save Order** on a new order. On an existing order the button reads **Update Order**, and an "Unsaved changes" label appears once something is changed.
- No print buttons yet.

### 5.6 Saving rules

- To save, the order needs: customer name, BD number, and at least one item.
- If something is missing, do not save, and show a clear message naming what is missing (for example "Please add the customer name and at least one item.").
- When a new BD number is saved, a new Officer customer is created automatically (name, BD number, phone).
- A new order gets the next Officer order number: 1, 2, 3 …

## 6. Order Details screen

- **Header:** order number, "Officer" badge, customer name, status badge (Pending).
- **Customer info:** name, phone, BD number.
- **Order info:** order date, delivery date, ribbon.
- **Payment info:** total, discount, advance, due.
- **Items list:** name, quantity, price, line total.
- **Measurements and notes** as filled in.
- Bottom button: **Edit Order**.

## 7. Delete

- Delete icon on the card (and on Order Details).
- **Two steps.** Step 1: a dialog "Delete order #N for NAME?" with Cancel and Continue. Step 2: a second dialog "This cannot be undone. Delete permanently?" with Cancel and Delete.
- A deleted order is gone forever. The customer and their other orders stay.
- **Order numbers close the gap:** every later Officer order moves down by one (delete #522 and #523 becomes #522).

## 8. Data to store

- **Customer:** BD number (unique among Officers), name, phone.
- **Order:** order number, customer BD number and name, order date, delivery date, ribbon, status (always Pending for now), discount value and type, advance, total, measurements (shirt, pant, notes).
- **Order items:** item name, quantity, price copied at that time.
- **Settings:** item list with prices, default discount type, ribbon values.

Officer and Airman data are completely separate in the database, even though Airman is not built yet.

## 9. Starter items (৳)

Keep the spelling exactly as written. "check" means unconfirmed.

Battle Uniform 800 · Half Sleeve Shirt 250 · Full Sleeve Shirt 250 · Uniform Pant 200 · Summer Ceremonial 1500 · Winter Ceremonial 1000 · Half Bush 1000 · Civil Shirt 500 · Civil Pant 600 (check) · Punjabi 500 · Paijama 400 · Jubba 800 (check) · Safari 2000 · Blazer 4000 · Suit 5000 · Meskit 2200 · Meskit Shirt 400 · APPULATE (MESKIT 700 (check) · keti 2000 · maintainnce coverall 1000 · MESKIT PANT 200 (check) · DUST COAT 400 · MISSON GANJI 1000 · FOTUA 400 · HALF BUSH UPOR PART 800 (check) · summer ceremonial upor part 1300 (check) · sleeping dress 600 (check)

MODC Uniform has no price and is for Airman orders only, so do not add it in this loop.

## 10. Look and feel

Clean and modern, white cards, soft colours. Blue for main buttons, red for money owed, orange for the Pending badge. Works on phones and computers.

## 11. Not in this loop (do not build)

Status changing, Delivery screen, Pay button, tabs, Upcoming and Due After Delivery cards, printing (invoice and cutting slip), drafts and local autosave, the Customers and Customer History pages, name suggestions while typing, Airman orders, Dashboard, Bangla, dark mode, install as an app, invoice template, upcoming-days setting, login, Branch, Export, staff pages, notifications, online payments.

## 12. Done checklist (test in this order)

1. Open Settings: the starter items are there; add an item, change a price, remove the new item.
2. New Order: try to save with nothing filled in. A clear message appears and nothing is saved.
3. Add Battle Uniform and Half Sleeve Shirt. Total is 1050. Enter a BD number, name, advance 200. Due is 850. Save. The order is #1.
4. Add a second order with a discount of 10% and check Total, Discount and Due.
5. Use the same BD number again: the name fills in automatically.
6. The Orders list shows both orders with Due in red. Search by name, phone, BD number and order number each finds the right order.
7. Open an order: all details, items and measurements show.
8. Edit an order: "Unsaved changes" appears, the button reads Update Order, and the new Total and Due are right.
9. Change an item price in Settings: old orders keep their old prices.
10. Add a third order, then delete order #2 with both confirmation steps. The old #3 becomes #2, and the customer still exists.
11. Open the app on a second device: the same orders appear.
12. The word "optional" appears nowhere.
