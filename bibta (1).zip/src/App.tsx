import React, { useState } from 'react';
import { AppProvider } from './context/AppContext.tsx';
import { Navbar, ScreenName } from './components/Navbar.tsx';
import { OfficerOrdersScreen } from './components/OfficerOrdersScreen.tsx';
import { OfficerOrderForm } from './components/OfficerOrderForm.tsx';
import { AirmanOrdersScreen } from './components/AirmanOrdersScreen.tsx';
import { AirmanOrderForm } from './components/AirmanOrderForm.tsx';
import { OrderDetailsScreen } from './components/OrderDetailsScreen.tsx';
import { DeliveryScreen } from './components/DeliveryScreen.tsx';
import { DraftsScreen } from './components/DraftsScreen.tsx';
import { CustomersScreen } from './components/CustomersScreen.tsx';
import { CustomerHistoryScreen } from './components/CustomerHistoryScreen.tsx';
import { StaffManagementScreen } from './components/StaffManagementScreen.tsx';
import { WorkerPage } from './components/WorkerPage.tsx';
import { StaffSummaryScreen } from './components/StaffSummaryScreen.tsx';
import { DashboardScreen } from './components/DashboardScreen.tsx';
import { SettingsScreen } from './components/SettingsScreen.tsx';
import { PrintPreviewScreen } from './components/PrintPreviewScreen.tsx';
import { AppFrame } from './components/polaris/AppFrame.tsx';

function MainApp() {
  const [currentScreen, setCurrentScreen] = useState<ScreenName>('orders');
  const [screenParams, setScreenParams] = useState<any>({});

  React.useEffect(() => {
    const titles: Record<ScreenName, string> = {
      'orders': 'Officer Orders',
      'airman-orders': 'Airman Orders',
      'delivery': 'Delivery',
      'drafts': 'Drafts',
      'customers': 'Customers',
      'customer-history': 'Customer History',
      'staff-management': 'Staff Management',
      'worker-page': 'Worker Details',
      'staff-summary': 'Staff Summary',
      'dashboard': 'Dashboard',
      'settings': 'Settings',
      'new-officer-order': 'New Officer Order',
      'edit-officer-order': 'Edit Officer Order',
      'new-airman-order': 'New Airman Order',
      'edit-airman-order': 'Edit Airman Order',
      'order-details': 'Order Details',
      'worker-history': 'Worker History',
      'print-slip': 'Cutting Slip',
      'print-invoice': 'Invoice',
      'print-worker-statement': 'Payslip',
    };
    const title = titles[currentScreen] || 'Orders';
    document.title = `${title} · Raymond`;
  }, [currentScreen]);

  const handleNavigate = (screen: ScreenName, params: any = {}) => {
    setCurrentScreen(screen);
    setScreenParams(params);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const renderScreen = () => {
    switch (currentScreen) {
      case 'orders':
        return <OfficerOrdersScreen onNavigate={handleNavigate} />;
      case 'new-officer-order':
        return <OfficerOrderForm draftId={screenParams.draftId} onNavigate={handleNavigate} />;
      case 'edit-officer-order':
        return <OfficerOrderForm orderNumber={screenParams.orderNumber} onNavigate={handleNavigate} />;
      case 'airman-orders':
        return <AirmanOrdersScreen onNavigate={handleNavigate} />;
      case 'new-airman-order':
        return <AirmanOrderForm draftId={screenParams.draftId} onNavigate={handleNavigate} />;
      case 'edit-airman-order':
        return <AirmanOrderForm orderNumber={screenParams.orderNumber} onNavigate={handleNavigate} />;
      case 'order-details':
        return (
          <OrderDetailsScreen
            orderNumber={screenParams.orderNumber}
            category={screenParams.category || 'Officer'}
            onNavigate={handleNavigate}
          />
        );
      case 'delivery':
        return <DeliveryScreen onNavigate={handleNavigate} />;
      case 'drafts':
        return <DraftsScreen onNavigate={handleNavigate} />;
      case 'customers':
        return <CustomersScreen onNavigate={handleNavigate} />;
      case 'customer-history':
        return (
          <CustomerHistoryScreen
            initialBdNumber={screenParams.bdNumber}
            initialCategory={screenParams.category}
            onNavigate={handleNavigate}
          />
        );
      case 'staff-management':
        return <StaffManagementScreen onNavigate={handleNavigate} />;
      case 'worker-page':
        return (
          <WorkerPage
            workerId={screenParams.workerId}
            initialMonth={screenParams.month}
            onNavigate={handleNavigate}
          />
        );
      case 'staff-summary':
        return <StaffSummaryScreen onNavigate={handleNavigate} />;
      case 'dashboard':
        return <DashboardScreen onNavigate={handleNavigate} />;
      case 'settings':
        return <SettingsScreen />;
      case 'print-slip':
        return (
          <PrintPreviewScreen
            type="slip"
            orderNumber={screenParams.orderNumber}
            category={screenParams.category}
            onNavigate={handleNavigate}
          />
        );
      case 'print-invoice':
        return (
          <PrintPreviewScreen
            type="invoice"
            orderNumber={screenParams.orderNumber}
            category="Officer"
            onNavigate={handleNavigate}
          />
        );
      case 'print-worker-statement':
        return (
          <PrintPreviewScreen
            type="worker-statement"
            workerId={screenParams.workerId}
            month={screenParams.month}
            onNavigate={handleNavigate}
          />
        );
      default:
        return <OfficerOrdersScreen onNavigate={handleNavigate} />;
    }
  };

  if (currentScreen.startsWith('print-')) {
    return <div className="min-h-screen bg-white">{renderScreen()}</div>;
  }

  return (
    <AppFrame currentScreen={currentScreen} onNavigate={handleNavigate}>
      {renderScreen()}
    </AppFrame>
  );
}

export default function App() {
  return (
    <AppProvider>
      <MainApp />
    </AppProvider>
  );
}
