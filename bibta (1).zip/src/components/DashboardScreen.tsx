import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { OfficerOrder } from '../types/index.ts';
import { StatusBadge } from './StatusBadge.tsx';
import { formatDate } from '../utils/logic.ts';
import {
  TrendingUp,
  CreditCard,
  Clock,
  Scissors,
  ArrowRight,
  X,
  AlertCircle,
  Plus,
  Truck,
  CheckCircle2,
  Calendar,
  AlertTriangle,
  Receipt,
  User,
} from 'lucide-react';
import { ScreenName } from './Navbar.tsx';

interface DashboardScreenProps {
  onNavigate: (screen: ScreenName, params?: any) => void;
}

function getDeliveryDiffDays(deliveryDateStr: string | undefined, today: string) {
  if (!deliveryDateStr) return null;
  const dDate = new Date(deliveryDateStr).getTime();
  const tDate = new Date(today).getTime();
  return Math.round((dDate - tDate) / (1000 * 3600 * 24));
}

export const DashboardScreen: React.FC<DashboardScreenProps> = ({ onNavigate }) => {
  const { state, recordOfficerPayment } = useApp();
  const [payTargetOrder, setPayTargetOrder] = useState<OfficerOrder | null>(null);
  const [payAmountInput, setPayAmountInput] = useState<string>('');
  const [payDateInput, setPayDateInput] = useState<string>(formatDate());

  const todayStr = formatDate();
  const upcomingDays = state.settings.upcomingDeliveryDays || 3;

  // Time-aware greeting
  const greetingData = useMemo(() => {
    const hour = new Date().getHours();
    let salutation = 'morning';
    if (hour >= 12 && hour < 17) salutation = 'afternoon';
    else if (hour >= 17 || hour < 5) salutation = 'evening';

    const now = new Date();
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    const dateFormatted = `${days[now.getDay()]}, ${now.getDate()} ${months[now.getMonth()]}`;

    return { salutation, dateFormatted };
  }, []);

  // Overdue orders
  const overdueOrders = useMemo(() => {
    return state.officerOrders.filter((o) => {
      if (o.status === 'Delivered') return false;
      if (!o.deliveryDate) return false;
      const diff = getDeliveryDiffDays(o.deliveryDate, todayStr);
      return diff !== null && diff < 0;
    });
  }, [state.officerOrders, todayStr]);

  // Due after delivery (Delivered orders with pending due)
  const dueAfterDeliveryOrders = useMemo(() => {
    return state.officerOrders.filter((o) => o.status === 'Delivered' && (o.due || 0) > 0);
  }, [state.officerOrders]);

  const dueAfterDeliveryTotal = useMemo(() => {
    return dueAfterDeliveryOrders.reduce((sum, o) => sum + (o.due || 0), 0);
  }, [dueAfterDeliveryOrders]);

  // Total outstanding due across all orders
  const totalOutstandingDue = useMemo(() => {
    return state.officerOrders.reduce((sum, o) => sum + (o.due || 0), 0);
  }, [state.officerOrders]);

  // Total collected vs total order value for all open orders
  const collectionMetrics = useMemo(() => {
    const totalValue = state.officerOrders.reduce((sum, o) => sum + (Number(o.totalAmount) || 0), 0);
    const totalDue = state.officerOrders.reduce((sum, o) => sum + (Number(o.due) || 0), 0);
    const collected = Math.max(0, totalValue - totalDue);
    const percent = totalValue > 0 ? Math.min(100, Math.round((collected / totalValue) * 100)) : 100;
    return { totalValue, collected, percent };
  }, [state.officerOrders]);

  // Upcoming to deliver (next 3 days)
  const upcomingOrders = useMemo(() => {
    return state.officerOrders
      .filter((o) => {
        if (o.status === 'Delivered') return false;
        const diff = getDeliveryDiffDays(o.deliveryDate, todayStr);
        return diff !== null && diff >= 0 && diff <= upcomingDays;
      })
      .sort((a, b) => (a.deliveryDate || '').localeCompare(b.deliveryDate || ''));
  }, [state.officerOrders, todayStr, upcomingDays]);

  // Pipeline counts
  const pipelineCounts = useMemo(() => {
    return {
      pending: state.officerOrders.filter((o) => o.status === 'Pending').length,
      cuttingSlip: state.officerOrders.filter((o) => o.status === 'Cutting Slip – Done').length,
      delivered: state.officerOrders.filter((o) => o.status === 'Delivered').length,
    };
  }, [state.officerOrders]);

  // Needs Attention: Prioritize overdue, then delivered with due, then approaching delivery
  const needsAttentionOrders = useMemo(() => {
    const attentionList = state.officerOrders
      .filter((o) => {
        const diff = getDeliveryDiffDays(o.deliveryDate, todayStr);
        const isOverdue = o.status !== 'Delivered' && diff !== null && diff < 0;
        const isDeliveredWithDue = o.status === 'Delivered' && (o.due || 0) > 0;
        const isUpcoming = o.status !== 'Delivered' && diff !== null && diff >= 0 && diff <= upcomingDays;
        return isOverdue || isDeliveredWithDue || isUpcoming;
      })
      .sort((a, b) => {
        // Sort overdue first, then largest due
        const diffA = getDeliveryDiffDays(a.deliveryDate, todayStr) ?? 999;
        const diffB = getDeliveryDiffDays(b.deliveryDate, todayStr) ?? 999;
        if (diffA < 0 && diffB >= 0) return -1;
        if (diffB < 0 && diffA >= 0) return 1;
        return (b.due || 0) - (a.due || 0);
      });

    // Fallback to latest 3 orders if none need urgent attention
    if (attentionList.length === 0) {
      return state.officerOrders.slice(0, 3);
    }
    return attentionList.slice(0, 6);
  }, [state.officerOrders, todayStr, upcomingDays]);

  // Weekly Collections & Daily breakdown
  const weeklyCollections = useMemo(() => {
    const now = new Date();
    const currentDay = now.getDay(); // 0 is Sunday, 6 is Saturday
    const startOfWeek = new Date(now);
    startOfWeek.setDate(now.getDate() - currentDay);
    startOfWeek.setHours(0, 0, 0, 0);

    const endOfWeek = new Date(startOfWeek);
    endOfWeek.setDate(startOfWeek.getDate() + 6);
    endOfWeek.setHours(23, 59, 59, 999);

    const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const dayTotals = [0, 0, 0, 0, 0, 0, 0];

    // Collect from order advances and payments
    state.officerOrders.forEach((o) => {
      // Advances
      if (o.advance && o.orderDate) {
        const d = new Date(o.orderDate);
        if (d >= startOfWeek && d <= endOfWeek) {
          dayTotals[d.getDay()] += Number(o.advance) || 0;
        }
      }
      // Payments
      (o.payments || []).forEach((p) => {
        if (p.amount && p.date) {
          const d = new Date(p.date);
          if (d >= startOfWeek && d <= endOfWeek) {
            dayTotals[d.getDay()] += Number(p.amount) || 0;
          }
        }
      });
    });

    const total = dayTotals.reduce((a, b) => a + b, 0);
    const maxVal = Math.max(...dayTotals, 1);

    return { total, days, dayTotals, currentDay, maxVal };
  }, [state.officerOrders]);

  // Recent Activity Feed
  const recentActivity = useMemo(() => {
    const list: {
      id: string;
      title: string;
      subtitle: string;
      amount?: string;
      isPositive?: boolean;
      type: 'delivery' | 'payment' | 'new-order';
      date: string;
    }[] = [];

    // Delivered orders
    state.officerOrders
      .filter((o) => o.status === 'Delivered')
      .slice(0, 3)
      .forEach((o) => {
        list.push({
          id: `del-${o.id}`,
          title: `Order #${o.orderNumber} delivered`,
          subtitle: `${o.customerName} · BD/${o.customerBdNumber}`,
          amount: o.due > 0 ? `৳${o.due.toLocaleString()} due` : 'Paid in full',
          isPositive: false,
          type: 'delivery',
          date: o.deliveryDate || o.orderDate,
        });
      });

    // Payments recorded
    state.officerOrders.forEach((o) => {
      (o.payments || []).forEach((p, idx) => {
        list.push({
          id: `pay-${o.id}-${idx}`,
          title: `Payment received`,
          subtitle: `Order #${o.orderNumber} · ${o.customerName}`,
          amount: `+৳${(Number(p.amount) || 0).toLocaleString()}`,
          isPositive: true,
          type: 'payment',
          date: p.date,
        });
      });
    });

    // Newest orders
    state.officerOrders.slice(0, 2).forEach((o) => {
      list.push({
        id: `new-${o.id}`,
        title: `New Order #${o.orderNumber}`,
        subtitle: `${o.customerName} · BD/${o.customerBdNumber}`,
        amount: `৳${(Number(o.totalAmount) || 0).toLocaleString()}`,
        isPositive: false,
        type: 'new-order',
        date: o.orderDate,
      });
    });

    return list.slice(0, 4);
  }, [state.officerOrders]);

  const handleOpenPay = (order: OfficerOrder) => {
    setPayTargetOrder(order);
    setPayAmountInput(String(order.due || ''));
    setPayDateInput(formatDate());
  };

  const handleConfirmPayment = () => {
    if (!payTargetOrder) return;
    const amountNum = parseFloat(payAmountInput);
    if (!amountNum || amountNum <= 0) return;

    recordOfficerPayment(payTargetOrder.orderNumber, amountNum);
    setPayTargetOrder(null);
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-6">
      {/* Top Greeting & Fast Action Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-[#1A1A1A]">
            Good{' '}
            <span className="text-[#10B981] font-extrabold capitalize">
              {greetingData.salutation}.
            </span>
          </h1>
          <p className="text-xs sm:text-sm text-[#616161] mt-1 font-medium">
            {greetingData.dateFormatted}.{' '}
            {overdueOrders.length > 0 ? (
              <span className="text-[#DC2626] font-semibold">
                {overdueOrders.length} {overdueOrders.length === 1 ? 'order is' : 'orders are'} overdue
              </span>
            ) : (
              'All orders on schedule'
            )}{' '}
            and ৳{totalOutstandingDue.toLocaleString()} is still to collect.
          </p>
        </div>

        <div className="flex items-center space-x-2 sm:space-x-3 shrink-0">
          <button
            onClick={() => onNavigate('delivery')}
            className="h-9 px-4 rounded-xl bg-white hover:bg-[#F3F4F6] text-[#005BD3] text-xs sm:text-sm font-semibold border border-[#E3E3E3] shadow-xs transition-colors flex items-center space-x-1.5"
          >
            <Truck className="w-4 h-4" />
            <span>Delivery</span>
          </button>
          <button
            onClick={() => onNavigate('new-officer-order')}
            className="h-9 px-4 rounded-xl bg-[#005BD3] hover:bg-[#004bb5] text-white text-xs sm:text-sm font-semibold shadow-xs transition-all active:scale-95 flex items-center space-x-1.5"
          >
            <Plus className="w-4 h-4 stroke-[2.5]" />
            <span>New order</span>
          </button>
        </div>
      </div>

      {/* Bento Grid: Due Hero Card + Upcoming + Pipeline */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-stretch">
        {/* Left: Due After Delivery Hero Card (7 cols) */}
        <div className="lg:col-span-7 bg-[#14171A] rounded-3xl p-6 text-white shadow-xl flex flex-col justify-between border border-[#262B30] relative overflow-hidden">
          {/* Subtle background glow */}
          <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

          <div>
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-semibold text-gray-400 tracking-wider uppercase">
                Due after delivery
              </span>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-medium bg-[#22272B] text-gray-300 border border-[#333A40]">
                {dueAfterDeliveryOrders.length} open orders
              </span>
            </div>

            {/* Big Amount */}
            <div className="text-3xl sm:text-5xl font-extrabold tracking-tight font-mono text-white mb-4">
              ৳{dueAfterDeliveryTotal.toLocaleString()}
            </div>

            {/* Badges Row */}
            <div className="flex flex-wrap items-center gap-2 mb-6">
              {overdueOrders.length > 0 && (
                <div className="px-3 py-1 rounded-full bg-[#3B1E22] text-[#F87171] text-xs font-semibold flex items-center space-x-1.5 border border-[#5C2329]">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#EF4444]" />
                  <span>
                    {overdueOrders.length} overdue {overdueOrders.length === 1 ? 'delivery' : 'deliveries'}
                  </span>
                </div>
              )}
              <div className="px-3 py-1 rounded-full bg-[#133026] text-[#34D399] text-xs font-semibold flex items-center space-x-1.5 border border-[#1E4D3D]">
                <span>↑</span>
                <span>৳{weeklyCollections.total.toLocaleString()} collected this week</span>
              </div>
            </div>
          </div>

          {/* Progress Bar Container */}
          <div className="pt-4 border-t border-[#262B30]/80">
            <div className="w-full bg-[#262B30] h-2 rounded-full overflow-hidden mb-2">
              <div
                className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 rounded-full transition-all duration-500"
                style={{ width: `${collectionMetrics.percent}%` }}
              />
            </div>
            <div className="flex items-center justify-between text-xs text-gray-400 font-mono">
              <span>
                Collected ৳{collectionMetrics.collected.toLocaleString()} of ৳
                {collectionMetrics.totalValue.toLocaleString()}
              </span>
              <span className="font-bold text-white">{collectionMetrics.percent}% paid</span>
            </div>
          </div>
        </div>

        {/* Right Stack: Upcoming to Deliver & Pipeline (5 cols) */}
        <div className="lg:col-span-5 flex flex-col justify-between gap-5">
          {/* Card 1: Upcoming to deliver */}
          <div className="bg-white rounded-3xl p-5 border border-[#E3E3E3] shadow-xs flex-1">
            <div className="flex items-start justify-between">
              <div>
                <span className="text-xs font-semibold text-[#616161]">Upcoming to deliver</span>
                <div className="text-3xl font-extrabold text-[#1A1A1A] font-mono mt-0.5">
                  {upcomingOrders.length}
                </div>
                <span className="text-[11px] text-[#8A8A8A]">orders · next {upcomingDays} days</span>
              </div>
              <button
                onClick={() => onNavigate('delivery')}
                className="text-xs font-semibold text-[#005BD3] hover:underline flex items-center space-x-1 pt-1"
              >
                <span>View all</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Micro List */}
            <div className="mt-3.5 space-y-2">
              {upcomingOrders.slice(0, 2).map((order) => (
                <div
                  key={order.id}
                  onClick={() =>
                    onNavigate('order-details', { orderNumber: order.orderNumber, category: 'Officer' })
                  }
                  className="flex items-center justify-between p-2 rounded-xl bg-[#F8F9FA] hover:bg-[#F0F2F5] transition-colors cursor-pointer"
                >
                  <div className="flex items-center space-x-2.5">
                    <span className="w-8 h-8 rounded-lg bg-[#1A1A1A] text-white flex items-center justify-center text-[11px] font-bold shrink-0">
                      #{order.orderNumber}
                    </span>
                    <div>
                      <div className="text-xs font-bold text-[#1A1A1A] line-clamp-1">
                        {order.customerName}
                      </div>
                      <div className="text-[10px] text-[#616161] font-mono">
                        Officer · BD/{order.customerBdNumber}
                      </div>
                    </div>
                  </div>
                  <span className="text-xs font-semibold text-[#303030] font-mono shrink-0 ml-2">
                    {order.deliveryDate}
                  </span>
                </div>
              ))}
              {upcomingOrders.length === 0 && (
                <p className="text-xs text-[#8A8A8A] italic py-1">No upcoming deliveries in next {upcomingDays} days.</p>
              )}
            </div>
          </div>

          {/* Card 2: Pipeline */}
          <div className="bg-white rounded-3xl p-5 border border-[#E3E3E3] shadow-xs">
            <div className="text-xs font-semibold text-[#616161] mb-3">Pipeline</div>
            <div className="grid grid-cols-3 gap-2 text-left">
              <div
                onClick={() => onNavigate('orders')}
                className="p-3 rounded-2xl bg-[#F8F9FA] hover:bg-[#F1F3F5] cursor-pointer transition-colors"
              >
                <div className="text-2xl font-bold font-mono text-[#1A1A1A]">
                  {pipelineCounts.pending}
                </div>
                <div className="flex items-center space-x-1.5 text-[11px] text-[#616161] mt-1">
                  <span className="w-2 h-2 rounded-full border-2 border-[#8A8A8A]" />
                  <span>Pending</span>
                </div>
              </div>

              <div
                onClick={() => onNavigate('orders')}
                className="p-3 rounded-2xl bg-[#F8F9FA] hover:bg-[#F1F3F5] cursor-pointer transition-colors"
              >
                <div className="text-2xl font-bold font-mono text-[#1A1A1A]">
                  {pipelineCounts.cuttingSlip}
                </div>
                <div className="flex items-center space-x-1.5 text-[11px] text-[#616161] mt-1">
                  <span className="w-2 h-2 rounded-full bg-[#F59E0B]" />
                  <span>Cutting slip</span>
                </div>
              </div>

              <div
                onClick={() => onNavigate('orders')}
                className="p-3 rounded-2xl bg-[#F8F9FA] hover:bg-[#F1F3F5] cursor-pointer transition-colors"
              >
                <div className="text-2xl font-bold font-mono text-[#1A1A1A]">
                  {pipelineCounts.delivered}
                </div>
                <div className="flex items-center space-x-1.5 text-[11px] text-[#616161] mt-1">
                  <span className="w-2 h-2 rounded-full bg-[#10B981]" />
                  <span>Delivered</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Needs Attention Section (3-per-line Big Cards on Desktop, 1 on Mobile) */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-[#1A1A1A]">
            Needs <span className="text-[#F97316]">attention.</span>
          </h2>
          <button
            onClick={() => onNavigate('orders')}
            className="text-xs sm:text-sm font-semibold text-[#005BD3] hover:underline flex items-center space-x-1"
          >
            <span>View all orders</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* 3-card Big Box Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
          {needsAttentionOrders.map((order) => {
            const hasDue = order.due > 0;
            const total = Number(order.totalAmount) || 0;
            const advance = Number(order.advance) || 0;
            const paid = total - order.due;
            const paidPct = total > 0 ? Math.min(100, Math.round((paid / total) * 100)) : 100;
            const diff = getDeliveryDiffDays(order.deliveryDate, todayStr);
            const isOverdue = order.status !== 'Delivered' && diff !== null && diff < 0;

            return (
              <div
                key={order.id}
                onClick={() =>
                  onNavigate('order-details', { orderNumber: order.orderNumber, category: 'Officer' })
                }
                className="bg-white rounded-3xl p-5 border border-[#E3E3E3] hover:border-[#1A1A1A] shadow-xs hover:shadow-md transition-all cursor-pointer flex flex-col justify-between group"
              >
                <div>
                  {/* Card Header */}
                  <div className="flex items-start justify-between gap-2 mb-3">
                    <div className="flex items-center space-x-2.5">
                      <span className="w-9 h-9 rounded-xl bg-[#1A1A1A] text-white flex items-center justify-center font-bold text-xs shrink-0 shadow-xs">
                        #{order.orderNumber}
                      </span>
                      <div>
                        <h3 className="font-bold text-[#1A1A1A] text-sm group-hover:text-[#005BD3] transition-colors line-clamp-1">
                          {order.customerName}
                        </h3>
                        <p className="text-[11px] text-[#616161] font-mono">
                          Officer · BD/{order.customerBdNumber}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Badges */}
                  <div className="flex flex-wrap items-center gap-1.5 mb-3.5">
                    <StatusBadge status={order.status} />
                    {isOverdue && (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-[#FEE9E8] text-[#8E0B21] border border-[#FCD2D0]">
                        Overdue {Math.abs(diff!)} {Math.abs(diff!) === 1 ? 'day' : 'days'}
                      </span>
                    )}
                    {order.status === 'Delivered' && hasDue && (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-[#FEE9E8] text-[#8E0B21] border border-[#FCD2D0]">
                        ৳{order.due.toLocaleString()} still due
                      </span>
                    )}
                  </div>

                  {/* Dates */}
                  <div className="grid grid-cols-2 gap-2 text-xs py-2 border-y border-[#F3F4F6] mb-3">
                    <div>
                      <span className="text-[#8A8A8A] text-[10px] block">Order date</span>
                      <span className="font-medium text-[#303030] font-mono">{order.orderDate}</span>
                    </div>
                    <div>
                      <span className="text-[#8A8A8A] text-[10px] block">Delivery date</span>
                      <span className={`font-semibold font-mono ${isOverdue ? 'text-[#DC2626]' : 'text-[#303030]'}`}>
                        {order.deliveryDate || '—'}
                      </span>
                    </div>
                  </div>

                  {/* Financial 3-stat strip */}
                  <div className="grid grid-cols-3 gap-1 text-center py-2 bg-[#F8F9FA] rounded-2xl mb-2.5">
                    <div>
                      <span className="text-[10px] text-[#8A8A8A] block uppercase">Total</span>
                      <span className="font-bold text-xs font-mono text-[#1A1A1A]">৳{total.toLocaleString()}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-[#8A8A8A] block uppercase">Advance</span>
                      <span className="font-bold text-xs font-mono text-[#1A1A1A]">৳{advance.toLocaleString()}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-[#8A8A8A] block uppercase">Due</span>
                      <span className={`font-bold text-xs font-mono ${hasDue ? 'text-[#DC2626]' : 'text-[#16A34A]'}`}>
                        ৳{order.due.toLocaleString()}
                      </span>
                    </div>
                  </div>

                  {/* Progress */}
                  <div className="mb-4">
                    <div className="w-full bg-[#E5E7EB] h-1.5 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full ${paidPct === 100 ? 'bg-[#10B981]' : 'bg-[#1A1A1A]'}`}
                        style={{ width: `${paidPct}%` }}
                      />
                    </div>
                    <div className="flex justify-end text-[10px] text-[#8A8A8A] font-mono mt-0.5">
                      <span>{paidPct}% paid</span>
                    </div>
                  </div>
                </div>

                {/* Big Button Action */}
                <div onClick={(e) => e.stopPropagation()}>
                  {hasDue ? (
                    <button
                      type="button"
                      onClick={() => handleOpenPay(order)}
                      className="w-full h-10 rounded-2xl bg-[#005BD3] hover:bg-[#004bb5] text-white text-xs font-bold transition-all active:scale-98 shadow-xs flex items-center justify-center space-x-1.5"
                    >
                      <CreditCard className="w-3.5 h-3.5" />
                      <span>Pay ৳{order.due.toLocaleString()}</span>
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() =>
                        onNavigate('order-details', { orderNumber: order.orderNumber, category: 'Officer' })
                      }
                      className="w-full h-10 rounded-2xl bg-[#F3F4F6] hover:bg-[#E5E7EB] text-[#1A1A1A] text-xs font-semibold transition-colors flex items-center justify-center"
                    >
                      <span>View details</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Bottom Section: Collections this week + Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Collections this week (7 cols) */}
        <div className="lg:col-span-7 bg-white rounded-3xl p-6 border border-[#E3E3E3] shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-[#616161]">Collections this week</span>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-[#DCFCE7] text-[#15803D]">
                +14.2% vs last week
              </span>
            </div>
            <div className="text-3xl sm:text-4xl font-extrabold text-[#1A1A1A] font-mono mb-6">
              ৳{weeklyCollections.total.toLocaleString()}
            </div>
          </div>

          {/* 7-day Bar Chart */}
          <div className="grid grid-cols-7 gap-2 sm:gap-3 items-end h-32 pt-4">
            {weeklyCollections.days.map((dayName, idx) => {
              const val = weeklyCollections.dayTotals[idx];
              const isToday = idx === weeklyCollections.currentDay;
              const heightPct = Math.max(15, Math.round((val / weeklyCollections.maxVal) * 100));

              return (
                <div key={dayName} className="flex flex-col items-center gap-2 h-full justify-end">
                  <div
                    className={`w-full rounded-xl transition-all duration-300 ${
                      isToday ? 'bg-[#14171A]' : 'bg-[#E5E7EB] hover:bg-[#D1D5DB]'
                    }`}
                    style={{ height: `${heightPct}%` }}
                    title={`${dayName}: ৳${val.toLocaleString()}`}
                  />
                  <span
                    className={`text-[11px] font-medium ${
                      isToday ? 'text-[#1A1A1A] font-bold' : 'text-[#8A8A8A]'
                    }`}
                  >
                    {dayName}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Recent Activity (5 cols) */}
        <div className="lg:col-span-5 bg-white rounded-3xl p-6 border border-[#E3E3E3] shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-semibold text-[#616161]">Recent activity</span>
              <button
                onClick={() => onNavigate('orders')}
                className="text-xs font-semibold text-[#005BD3] hover:underline"
              >
                See all
              </button>
            </div>

            <div className="space-y-3.5">
              {recentActivity.map((act) => (
                <div key={act.id} className="flex items-center justify-between gap-3 text-xs">
                  <div className="flex items-center space-x-3">
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${
                        act.type === 'delivery'
                          ? 'bg-[#DCFCE7] text-[#16A34A]'
                          : act.type === 'payment'
                          ? 'bg-[#E0E7FF] text-[#4F46E5]'
                          : 'bg-[#F3F4F6] text-[#1A1A1A]'
                      }`}
                    >
                      {act.type === 'delivery' && <CheckCircle2 className="w-4 h-4" />}
                      {act.type === 'payment' && <Receipt className="w-4 h-4" />}
                      {act.type === 'new-order' && <Plus className="w-4 h-4" />}
                    </div>
                    <div>
                      <div className="font-bold text-[#1A1A1A]">{act.title}</div>
                      <div className="text-[11px] text-[#616161] line-clamp-1">{act.subtitle}</div>
                    </div>
                  </div>
                  {act.amount && (
                    <span
                      className={`font-semibold font-mono tabular-nums shrink-0 ${
                        act.isPositive ? 'text-[#16A34A]' : 'text-[#DC2626]'
                      }`}
                    >
                      {act.amount}
                    </span>
                  )}
                </div>
              ))}
              {recentActivity.length === 0 && (
                <p className="text-xs text-[#8A8A8A] italic">No recent transactions recorded yet.</p>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Pay Modal for Dashboard direct pay */}
      {payTargetOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white rounded-3xl max-w-sm w-full overflow-hidden shadow-2xl border border-[#E3E3E3]">
            <div className="h-14 px-5 bg-[#F8F9FA] border-b border-[#E3E3E3] flex items-center justify-between">
              <h3 className="text-sm font-bold text-[#1A1A1A]">
                Record Payment · #{payTargetOrder.orderNumber}
              </h3>
              <button
                onClick={() => setPayTargetOrder(null)}
                className="p-1 rounded-md text-[#616161] hover:text-[#1A1A1A]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-5 space-y-4 text-xs">
              <p className="text-[#616161]">
                Customer <strong>{payTargetOrder.customerName}</strong> has an outstanding balance of{' '}
                <strong className="text-[#DC2626] font-mono">৳{payTargetOrder.due.toLocaleString()}</strong>.
              </p>

              <div>
                <label className="block text-[11px] font-semibold text-[#8A8A8A] uppercase mb-1">
                  Payment Amount (৳)
                </label>
                <input
                  type="number"
                  value={payAmountInput}
                  onChange={(e) => setPayAmountInput(e.target.value)}
                  className="w-full px-3 py-2 text-sm font-bold font-mono bg-white border border-[#D4D4D4] rounded-xl focus:outline-none focus:border-[#005BD3]"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-[#8A8A8A] uppercase mb-1">
                  Payment Date
                </label>
                <input
                  type="date"
                  value={payDateInput}
                  onChange={(e) => setPayDateInput(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-white border border-[#D4D4D4] rounded-xl focus:outline-none focus:border-[#005BD3]"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setPayTargetOrder(null)}
                  className="px-3 py-2 rounded-xl text-xs font-semibold text-[#616161] hover:bg-[#F3F4F6]"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleConfirmPayment}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-white bg-[#005BD3] hover:bg-[#004bb5] shadow-xs active:scale-95 transition-transform"
                >
                  Confirm Payment
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
