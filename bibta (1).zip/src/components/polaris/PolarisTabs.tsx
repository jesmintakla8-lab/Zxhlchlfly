import React from 'react';

export interface TabItem<T extends string = string> {
  id: T;
  label: string;
  count?: number;
}

interface PolarisTabsProps<T extends string = string> {
  tabs: TabItem<T>[];
  selectedTab: T;
  onSelectTab: (tabId: T) => void;
  tools?: React.ReactNode;
}

export function PolarisTabs<T extends string = string>({
  tabs,
  selectedTab,
  onSelectTab,
  tools,
}: PolarisTabsProps<T>) {
  return (
    <div className="flex flex-col sm:flex-row sm:items-center justify-between px-3 py-2 border-b border-[#E3E3E3] gap-2 bg-white">
      {/* Tabs Row */}
      <div className="flex items-center space-x-1 overflow-x-auto pb-0.5 sm:pb-0" role="tablist">
        {tabs.map((tab) => {
          const isSelected = selectedTab === tab.id;
          return (
            <button
              key={tab.id}
              role="tab"
              aria-selected={isSelected}
              onClick={() => onSelectTab(tab.id)}
              className={`h-7 px-3 rounded-lg text-[13px] font-[450] flex items-center space-x-1.5 transition-colors whitespace-nowrap cursor-pointer ${
                isSelected
                  ? 'bg-[#EBEBEB] text-[#303030] font-[550]'
                  : 'text-[#616161] hover:bg-black/5 hover:text-[#303030]'
              }`}
            >
              <span>{tab.label}</span>
              {tab.count !== undefined && (
                <span
                  className={`text-[11px] px-1.5 py-0.2 rounded-full font-medium ${
                    isSelected ? 'bg-white text-[#303030]' : 'bg-[#EBEBEB] text-[#616161]'
                  }`}
                >
                  {tab.count}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Right Tools Slot (Search, Sort, Filters) */}
      {tools && <div className="shrink-0 flex items-center space-x-2">{tools}</div>}
    </div>
  );
}
