import React from 'react';
import { useApp } from '../context/AppContext.tsx';
import { calculateWorkerMonthHishab, formatDate } from '../utils/logic.ts';
import { Printer, ArrowLeft, RefreshCw, Scissors, FileText } from 'lucide-react';
import { ScreenName } from './Navbar.tsx';

interface PrintPreviewScreenProps {
  type: 'slip' | 'invoice' | 'worker-statement';
  orderNumber?: number;
  category?: 'Officer' | 'Airman';
  workerId?: string;
  month?: string;
  onNavigate: (screen: ScreenName, params?: any) => void;
}

export const PrintPreviewScreen: React.FC<PrintPreviewScreenProps> = ({
  type,
  orderNumber,
  category = 'Officer',
  workerId,
  month,
  onNavigate,
}) => {
  const { state } = useApp();

  const isOfficer = category === 'Officer';
  const officerOrder = isOfficer ? state.officerOrders.find((o) => o.orderNumber === orderNumber) : null;
  const airmanOrder = !isOfficer ? state.airmanOrders.find((o) => o.orderNumber === orderNumber) : null;
  const order = isOfficer ? officerOrder : airmanOrder;

  const worker = workerId ? state.workers.find((w) => w.id === workerId) : null;

  const handlePrint = () => {
    window.print();
  };

  const paperSize =
    type === 'invoice'
      ? state.settings.invoicePaperSize
      : state.settings.cuttingSlipPaperSize;

  return (
    <div className="min-h-screen bg-gray-100 py-6 print:py-0 print:bg-white">
      {/* Top Controls Toolbar (Hidden in print) */}
      <div className="max-w-4xl mx-auto px-4 mb-6 print:hidden flex flex-wrap items-center justify-between gap-3 bg-white p-4 rounded-xl border border-gray-200 shadow-xs">
        <div className="flex items-center space-x-2">
          <button
            onClick={() => onNavigate(order ? 'order-details' : 'staff-management', { orderNumber, category, workerId })}
            className="px-3 py-1.5 border border-gray-300 rounded-lg text-xs font-semibold text-gray-700 hover:bg-gray-50 flex items-center space-x-1"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back</span>
          </button>
          <span className="text-sm font-bold text-gray-900">
            {type === 'slip'
              ? `Cutting Slip — #${orderNumber} (${category})`
              : type === 'invoice'
              ? `Invoice — #${orderNumber}`
              : `Worker Statement — ${worker?.name} (${month})`}
          </span>
          <span className="text-xs px-2 py-0.5 rounded-md bg-gray-100 text-gray-600 font-mono">
            {paperSize}
          </span>
        </div>

        <div className="flex items-center space-x-2">
          {/* Switch to other paper for same order */}
          {type === 'slip' && isOfficer && (
            <button
              onClick={() => onNavigate('print-invoice', { orderNumber, category: 'Officer' })}
              className="px-3 py-1.5 text-xs font-medium text-blue-600 hover:underline flex items-center space-x-1"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Switch to Invoice</span>
            </button>
          )}

          {type === 'invoice' && (
            <button
              onClick={() => onNavigate('print-slip', { orderNumber, category: 'Officer' })}
              className="px-3 py-1.5 text-xs font-medium text-blue-600 hover:underline flex items-center space-x-1"
            >
              <Scissors className="w-3.5 h-3.5" />
              <span>Switch to Cutting Slip</span>
            </button>
          )}

          <button
            onClick={handlePrint}
            className="px-4 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold flex items-center space-x-1.5 shadow-xs"
          >
            <Printer className="w-4 h-4" />
            <span>Print Document</span>
          </button>
        </div>
      </div>

      {/* Printable Sheet Area */}
      <div
        className={`mx-auto bg-white border border-gray-300 shadow-lg print:border-0 print:shadow-none print:m-0 print:p-0 ${
          paperSize === 'A5' ? 'max-w-[148mm] min-h-[210mm] p-6' : 'max-w-[210mm] min-h-[297mm] p-8'
        }`}
      >
        {/* ================= TYPE: CUTTING SLIP ================= */}
        {type === 'slip' && order && (
          <div className="text-black font-sans space-y-4 text-xs">
            {/* Header */}
            <div className="border-b-2 border-black pb-3 text-center">
              <h1 className="text-xl font-extrabold uppercase tracking-wider">
                {state.settings.invoiceShopName || 'BAF Tailor & Outfitters'}
              </h1>
              <div className="text-base font-bold underline mt-1">
                {category} Cutting Slip
              </div>
            </div>

            {/* Order & Customer Meta */}
            <div className="grid grid-cols-2 gap-x-4 gap-y-1.5 border-b border-black pb-3">
              <div>
                <span className="font-bold">Order Number: </span>
                <span className="font-extrabold text-sm">#{order.orderNumber}</span>
              </div>
              <div>
                <span className="font-bold">Order Date: </span>
                <span>{order.orderDate}</span>
              </div>
              <div>
                <span className="font-bold">Customer Name: </span>
                <span className="font-bold text-sm">
                  {order.customerName || (category === 'Airman' ? `Airman ${order.customerBdNumber}` : '')}
                </span>
              </div>
              <div>
                <span className="font-bold">BD Number: </span>
                <span className="font-bold text-sm">{order.customerBdNumber}</span>
              </div>
              {isOfficer && (
                <div>
                  <span className="font-bold">Delivery Date: </span>
                  <span className="font-bold">{officerOrder?.deliveryDate || '—'}</span>
                </div>
              )}
              <div>
                <span className="font-bold">Ribbon: </span>
                <span>{order.ribbon}</span>
              </div>
              {!isOfficer && (
                <>
                  <div>
                    <span className="font-bold">Trade: </span>
                    <span>{airmanOrder?.trade || '—'}</span>
                  </div>
                  <div>
                    <span className="font-bold">Office: </span>
                    <span>{airmanOrder?.office || '—'}</span>
                  </div>
                </>
              )}
            </div>

            {/* Items list: NO prices and NO money anywhere on this paper! */}
            <div className="border-b border-black pb-3">
              <h2 className="font-bold text-xs uppercase tracking-wider mb-1.5">Items to Make</h2>
              {order.items.length > 0 ? (
                <table className="w-full text-left border border-black">
                  <thead>
                    <tr className="border-b border-black bg-gray-100">
                      <th className="p-1.5 border-r border-black w-10 text-center">#</th>
                      <th className="p-1.5 border-r border-black">Item Description</th>
                      <th className="p-1.5 border-r border-black w-20 text-center">Qty</th>
                      {!isOfficer && <th className="p-1.5 w-28 text-left">IV-Number</th>}
                    </tr>
                  </thead>
                  <tbody>
                    {order.items.map((item: any, i: number) => (
                      <tr key={i} className="border-b border-black">
                        <td className="p-1.5 border-r border-black text-center">{i + 1}</td>
                        <td className="p-1.5 border-r border-black font-bold">{item.name}</td>
                        <td className="p-1.5 border-r border-black text-center font-bold">{item.quantity}</td>
                        {!isOfficer && (
                          <td className="p-1.5 font-bold font-mono">{item.ivNumber}</td>
                        )}
                      </tr>
                    ))}
                  </tbody>
                </table>
              ) : (
                <p className="italic text-gray-600">
                  No cutting slip found for this category in the selected order.
                </p>
              )}
            </div>

            {/* Measurements: filled fields only */}
            <div className="space-y-3 border-b border-black pb-3">
              <h2 className="font-bold text-xs uppercase tracking-wider">Measurements</h2>

              {/* Shirt Measurements */}
              {(() => {
                const filled = Object.entries(order.shirtMeasurements || {}).filter(
                  ([k, v]) => v && k !== 'handWrittenNotes' && k !== 'extraNotes'
                );
                const hasNotes =
                  order.shirtMeasurements?.handWrittenNotes || order.shirtMeasurements?.extraNotes;

                if (filled.length === 0 && !hasNotes) return null;

                return (
                  <div className="border border-black p-2.5 rounded">
                    <span className="font-bold underline block mb-1">Shirt</span>
                    <div className="grid grid-cols-4 gap-2">
                      {filled.map(([k, v]) => (
                        <div key={k} className="border-b border-dotted border-gray-400 py-0.5">
                          <span className="capitalize text-gray-700">{k}: </span>
                          <span className="font-bold">{v}</span>
                        </div>
                      ))}
                    </div>
                    {order.shirtMeasurements?.handWrittenNotes && (
                      <div className="mt-1.5 pt-1 text-[11px] border-t border-gray-300">
                        <span className="font-bold">Hand Written Notes: </span>
                        <span>{order.shirtMeasurements.handWrittenNotes}</span>
                      </div>
                    )}
                    {order.shirtMeasurements?.extraNotes && (
                      <div className="mt-0.5 text-[11px]">
                        <span className="font-bold">Extra Notes: </span>
                        <span>{order.shirtMeasurements.extraNotes}</span>
                      </div>
                    )}
                  </div>
                );
              })()}

              {/* Pant Measurements */}
              {(() => {
                const filled = Object.entries(order.pantMeasurements || {}).filter(
                  ([k, v]) => v && k !== 'handWrittenNotes' && k !== 'extraNotes'
                );
                const hasNotes =
                  order.pantMeasurements?.handWrittenNotes || order.pantMeasurements?.extraNotes;

                if (filled.length === 0 && !hasNotes) return null;

                return (
                  <div className="border border-black p-2.5 rounded">
                    <span className="font-bold underline block mb-1">Pant</span>
                    <div className="grid grid-cols-4 gap-2">
                      {filled.map(([k, v]) => (
                        <div key={k} className="border-b border-dotted border-gray-400 py-0.5">
                          <span className="capitalize text-gray-700">{k}: </span>
                          <span className="font-bold">{v}</span>
                        </div>
                      ))}
                    </div>
                    {order.pantMeasurements?.handWrittenNotes && (
                      <div className="mt-1.5 pt-1 text-[11px] border-t border-gray-300">
                        <span className="font-bold">Hand Written Notes: </span>
                        <span>{order.pantMeasurements.handWrittenNotes}</span>
                      </div>
                    )}
                    {order.pantMeasurements?.extraNotes && (
                      <div className="mt-0.5 text-[11px]">
                        <span className="font-bold">Extra Notes: </span>
                        <span>{order.pantMeasurements.extraNotes}</span>
                      </div>
                    )}
                  </div>
                );
              })()}
            </div>

            <div className="text-right text-[10px] text-gray-500 pt-4">
              Printed on {formatDate()}
            </div>
          </div>
        )}

        {/* ================= TYPE: INVOICE ================= */}
        {type === 'invoice' && officerOrder && (
          <div className="text-black font-sans space-y-4 text-xs">
            {/* Header */}
            <div className="border-b-2 border-black pb-3 flex items-center justify-between">
              <div className="flex items-center space-x-3">
                {state.settings.invoiceLogo && (
                  <img
                    src={state.settings.invoiceLogo}
                    alt="Shop Logo"
                    className="w-12 h-12 object-contain"
                  />
                )}
                <div>
                  <h1 className="text-xl font-extrabold uppercase">
                    {state.settings.invoiceShopName || 'BAF Tailor & Outfitters'}
                  </h1>
                  <span className="text-sm font-bold tracking-widest uppercase">Invoice</span>
                </div>
              </div>
              <div className="text-right">
                <div className="text-base font-extrabold">#{officerOrder.orderNumber}</div>
                <div className="text-[11px]">Date: {officerOrder.orderDate}</div>
                {officerOrder.deliveryDate && (
                  <div className="text-[11px] font-semibold">Delivery: {officerOrder.deliveryDate}</div>
                )}
              </div>
            </div>

            {/* Customer Details */}
            <div className="border-b border-black pb-3 grid grid-cols-2 gap-2 text-xs">
              <div>
                <span className="font-bold">Customer Name: </span>
                <span className="font-extrabold text-sm">{officerOrder.customerName}</span>
              </div>
              <div>
                <span className="font-bold">BD Number: </span>
                <span className="font-bold">{officerOrder.customerBdNumber}</span>
              </div>
              {officerOrder.customerPhone && (
                <div>
                  <span className="font-bold">Phone: </span>
                  <span>{officerOrder.customerPhone}</span>
                </div>
              )}
            </div>

            {/* Items Table */}
            <div>
              <table className="w-full text-left border border-black text-xs">
                <thead>
                  <tr className="border-b border-black bg-gray-100">
                    <th className="p-1.5 border-r border-black w-8 text-center">#</th>
                    <th className="p-1.5 border-r border-black">Item</th>
                    <th className="p-1.5 border-r border-black w-14 text-center">Qty</th>
                    <th className="p-1.5 border-r border-black w-20 text-right">Price</th>
                    <th className="p-1.5 w-24 text-right">Line Total</th>
                  </tr>
                </thead>
                <tbody>
                  {officerOrder.items.map((item, idx) => (
                    <tr key={idx} className="border-b border-black">
                      <td className="p-1.5 border-r border-black text-center">{idx + 1}</td>
                      <td className="p-1.5 border-r border-black font-medium">{item.name}</td>
                      <td className="p-1.5 border-r border-black text-center">{item.quantity}</td>
                      <td className="p-1.5 border-r border-black text-right">৳{item.price}</td>
                      <td className="p-1.5 text-right font-semibold">৳{item.lineTotal}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Financial Calculations Block */}
            <div className="flex justify-end pt-2">
              <div className="w-64 border border-black p-2.5 space-y-1 text-xs">
                <div className="flex justify-between">
                  <span>Total Amount:</span>
                  <span className="font-bold">৳{officerOrder.totalAmount}</span>
                </div>
                {officerOrder.discountAmount > 0 && (
                  <div className="flex justify-between">
                    <span>Discount:</span>
                    <span>-৳{officerOrder.discountAmount}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span>Advance:</span>
                  <span>-৳{officerOrder.advance || 0}</span>
                </div>
                {/* Received Later line */}
                {(() => {
                  const later = (officerOrder.payments || []).reduce(
                    (s, p) => s + (Number(p.amount) || 0),
                    0
                  );
                  if (later <= 0) return null;
                  return (
                    <div className="flex justify-between text-emerald-800">
                      <span>Received Later:</span>
                      <span>-৳{later}</span>
                    </div>
                  );
                })()}
                <div className="flex justify-between border-t border-black pt-1 font-extrabold text-sm">
                  <span>Due:</span>
                  <span>৳{officerOrder.due}</span>
                </div>
              </div>
            </div>

            {/* Terms at Bottom */}
            {state.settings.invoiceTerms && (
              <div className="border-t border-black pt-3 mt-6 text-[10px] text-gray-700 whitespace-pre-line">
                <span className="font-bold block uppercase mb-0.5">Terms:</span>
                {state.settings.invoiceTerms}
              </div>
            )}
          </div>
        )}

        {/* ================= TYPE: WORKER STATEMENT ================= */}
        {type === 'worker-statement' && worker && month && (
          <div className="text-black font-sans space-y-4 text-xs">
            <div className="border-b-2 border-black pb-3 text-center">
              <h1 className="text-xl font-extrabold uppercase">
                {state.settings.invoiceShopName || 'BAF Tailor & Outfitters'}
              </h1>
              <div className="text-base font-bold underline mt-1">Staff Monthly Statement</div>
              <div className="text-sm font-semibold mt-1">
                Worker: {worker.name} {worker.banglaName && `(${worker.banglaName})`} · Month: {month}
              </div>
            </div>

            {/* Grid rows */}
            {(() => {
              const rows = state.workerRows.filter((r) => {
                if (r.workerId !== worker.id) return false;
                const rMonth = (r.date || '').slice(0, 7);
                const kMonth = (r.khorochDate || r.date || '').slice(0, 7);
                return rMonth === month || kMonth === month;
              });

              const payments = state.workerPayments.filter(
                (p) => p.workerId === worker.id && p.forMonth === month
              );

              const hishab = calculateWorkerMonthHishab(worker.id, state.workerRows, state.workerPayments, month);

              return (
                <div className="space-y-4">
                  <table className="w-full text-left border border-black text-[11px]">
                    <thead>
                      <tr className="border-b border-black bg-gray-100 font-bold">
                        <th className="p-1 border-r border-black">Date</th>
                        <th className="p-1 border-r border-black">Serial</th>
                        <th className="p-1 border-r border-black">BD</th>
                        <th className="p-1 border-r border-black">Item</th>
                        <th className="p-1 border-r border-black text-center">Qty</th>
                        <th className="p-1 border-r border-black text-right">Rate</th>
                        <th className="p-1 border-r border-black text-right">Total</th>
                        <th className="p-1 text-right">Khoroch</th>
                      </tr>
                    </thead>
                    <tbody>
                      {rows.map((r, i) => (
                        <tr key={i} className="border-b border-gray-300">
                          <td className="p-1 border-r border-black">{r.date}</td>
                          <td className="p-1 border-r border-black font-semibold">#{r.serial}</td>
                          <td className="p-1 border-r border-black">{r.bdNumber}</td>
                          <td className="p-1 border-r border-black">{r.item}</td>
                          <td className="p-1 border-r border-black text-center">{r.quantity}</td>
                          <td className="p-1 border-r border-black text-right">৳{r.unitPrice}</td>
                          <td className="p-1 border-r border-black text-right font-semibold">
                            ৳{r.totalTaka}
                          </td>
                          <td className="p-1 text-right font-semibold text-amber-900">
                            {r.khoroch ? `৳${r.khoroch}` : '—'}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>

                  {/* Payments list in statement (Loop 8 Section 3) */}
                  {payments.length > 0 && (
                    <div className="border border-black p-2 rounded">
                      <span className="font-bold underline block mb-1">Settlement Payments Received:</span>
                      <div className="space-y-0.5">
                        {payments.map((p, idx) => (
                          <div key={idx} className="flex justify-between">
                            <span>{p.date} {p.note && `(${p.note})`}</span>
                            <span className="font-bold">৳{p.amount}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Footer Totals */}
                  <div className="border-t-2 border-black pt-2 flex justify-end">
                    <div className="w-56 space-y-1 font-semibold">
                      <div className="flex justify-between">
                        <span>Total Work Earned:</span>
                        <span>৳{hishab.totalAmount}</span>
                      </div>
                      <div className="flex justify-between text-amber-800">
                        <span>Total Khoroch:</span>
                        <span>-৳{hishab.totalKhoroch}</span>
                      </div>
                      <div className="flex justify-between border-t border-black pt-0.5 font-bold">
                        <span>Net Payable:</span>
                        <span>৳{hishab.netPayable}</span>
                      </div>
                      <div className="flex justify-between text-emerald-800">
                        <span>Received Payments:</span>
                        <span>-৳{hishab.received}</span>
                      </div>
                      <div className="flex justify-between border-t-2 border-black pt-1 font-extrabold text-sm">
                        <span>Balance Due:</span>
                        <span>৳{hishab.due}</span>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })()}
          </div>
        )}
      </div>
    </div>
  );
};
